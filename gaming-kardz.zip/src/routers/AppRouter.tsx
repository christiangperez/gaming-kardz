import { useEffect, useState } from 'react';
import {
    BrowserRouter as Router,
    Route,
    Routes,
    Navigate,
} from 'react-router-dom';

import { useDispatch, useSelector } from 'react-redux';
import { ethers } from "ethers";

import NFTAbi from '../contractsData/NFT.json';
import NFTAddress from '../contractsData/NFT-address.json';
import MarketplaceAbi from '../contractsData/Marketplace.json';
import MarketplaceAddress from '../contractsData/Marketplace-address.json';
import { NotFoundScreen } from '../components/home/NotFoundScreen';
import { HomeScreen } from '../components/home/HomeScreen';
import { Navbar } from '../components/nav/Navbar';
import { MarketplaceScreen } from '../components/marketplace/MarketplaceScreen';
import { MyNFTsScreen } from '../components/marketplace/MyNFTsScreen';
import { IRootState } from '../redux/store/store';
import { MintProvisional } from '../components/marketplace/MintProvisional';
import { AboutScreen } from '../components/home/AboutScreen';
import { ConnectWalletScreen } from '../components/home/ConnectWalletScreen';
import { getContractOwner } from '../redux/actions/marketActions';
import { NFTDetailScreen } from '../components/marketplace/NFTDetailScreen';

export const AppRouter = () => {

    const dispatch = useDispatch();
    const { account, isOwner } = useSelector((state: IRootState) => state.market);

    const [loading, setLoading] = useState(true);

    // Metamask login/connect
    const web3Handler = async() => {
        
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });

        dispatch({ type: 'setAccount', payload: accounts[0] });
        // Get provider from Metamask
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        // Set signer
        const signer = provider.getSigner();

        loadContracts(signer);
    }

    const loadContracts = async(signer: any) => {
        // Get deployed copies of contracts
        const marketplace = new ethers.Contract(MarketplaceAddress.address, MarketplaceAbi.abi, signer);

        const nft = new ethers.Contract(NFTAddress.address, NFTAbi.abi, signer);

        dispatch({ type: 'setContracts', payload: { nft, marketplace }})
        setLoading(false);
    }

    useEffect(() => {
        if (!loading) {
            dispatch(getContractOwner());
        }

    }, [loading]);
    
    return (
        <Router>
            <Navbar web3Handler={web3Handler} account={account} isOwner={isOwner} />

            <Routes>
                <Route path='/home' element={<HomeScreen />} />

                {
                    (!loading) ? (
                        <>
                            <Route path='/mint' element={<MintProvisional />} />
                            <Route path='/market' element={<MarketplaceScreen />} />
                            <Route path='/mynfts' element={<MyNFTsScreen />} />
                            <Route path='/nft/:idNft' element={<NFTDetailScreen />} />
                        </>
                    ) : (
                        <>
                            <Route path='/mint' element={<ConnectWalletScreen />} />
                            <Route path='/market' element={<ConnectWalletScreen />} />
                            <Route path='/mynfts' element={<ConnectWalletScreen />} />
                            <Route path='/nft/:idNft' element={<ConnectWalletScreen />} />
                        </>
                    )
                }

                <Route path='/about' element={<AboutScreen />} />

                <Route path='/' element={<Navigate to='/home' />} />
                <Route path='*' element={<NotFoundScreen />} />
            </Routes>

        </Router>
    )
}