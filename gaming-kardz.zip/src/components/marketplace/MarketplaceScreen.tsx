import { useEffect } from 'react';
import { ethers } from "ethers";
import { useDispatch, useSelector } from 'react-redux';
import { IRootState } from '../../redux/store/store';
import { CardActionArea, Typography, Card, CardContent, 
  CardMedia, Container, CardActions, Button,
  Grid, CircularProgress, Box } from '@mui/material';
import { loadMarketplaceItems, purchaseMarketplaceItem } from '../../redux/actions/marketActions';
import { INFTItem } from '../../interfaces/marketplaceInterfaces';
import { useNavigate } from 'react-router-dom';

export const MarketplaceScreen = () => {

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { marketplaceItems, loadingMarketplaceItems, loadingPurchaseItem } = useSelector((state: IRootState) => state.market);

  const handleClickPurchaseItem = (item: INFTItem) => {
    dispatch(purchaseMarketplaceItem(item));
  }

  const handleClickCard = (item: INFTItem) => {
    navigate(`/nft/${item.itemId}`);
  }

  useEffect(() => {
    if (!loadingPurchaseItem) {
      dispatch(loadMarketplaceItems());
    }
  }, [loadingPurchaseItem]);

  if (loadingMarketplaceItems) {
    return (
      <Container maxWidth='xl' sx={{ background: '#0c1410' }}>
        <Grid 
          display='flex' 
          justifyContent='center' 
          alignItems='center' 
          sx={{ height: '90vh' }}
        >
          <Box sx={{ display: 'flex' }}>
            <CircularProgress />
          </Box>
        </Grid>
      </Container>
    );
  }

  return (
    <Container maxWidth='xl' sx={{ paddingTop: 2 }} style={{ background: 'linear-gradient(to right bottom, #0c1410, #192112)' }}>
    {
      (marketplaceItems.length > 0)
      ? (
        <>
          <Grid display='flex' justifyContent='center'>
            <Grid>
              <Typography color='white' variant='h2'>
                Market
              </Typography>
              <Typography color='white' variant='subtitle1'>
                Explore and collect your NFTs
              </Typography>
            </Grid>
          </Grid>
          <Grid container display='flex' justifyContent='center' sx={{ marginTop: 4 }}>
              {
                marketplaceItems.map((item, idx) => (
                  <Card 
                    key={idx} 
                    sx={{ maxWidth: 300, ml: 2, mr: 2, mb: 4 }} 
                    style={{ background: `linear-gradient(to right bottom, ${item.latestPrice > 0 ? '#5e7b37' : '#d0f177'}, #192112)` }}
                  >
                    <CardActionArea onClick={() => handleClickCard(item)}>
                      <CardMedia
                        component="img"
                        height="300"
                        src={item.image}
                        alt={item.name}
                      />
                      <CardContent>    

                        {/* Name */}
                        <Grid display='flex' justifyContent='space-between' alignItems='flex-end'>
                        {
                            <>
                              <Typography variant="caption" color='white' fontWeight='bold' fontSize={16}>
                                {item.name} <Typography variant="caption" color='white'>{` #${String(item.itemId)}`}</Typography>
                              </Typography>
                              <Typography variant="caption" color="white"  fontSize={16}>
                                Price
                              </Typography>
                              </>
                        }
                        </Grid>

                        {/* Team and price */}
                        <Grid display='flex' justifyContent='space-between' alignItems='flex-start'>
                        {
                            <>
                              <Grid display='flex' alignItems='center'>
                                <Typography variant="caption" color='white' textAlign='center' fontSize={14} fontWeight='600'>
                                  {
                                    (item.team ? item.team : item.game)
                                  }
                                </Typography>
                              </Grid>
                              <Grid display='flex' alignItems='center'>
                                <img
                                    src='../../assets/ether-gold.png'
                                    alt='logo'
                                    width={16}
                                    height={16}
                                    style={{ marginRight: 2 }}
                                />
                                <Typography variant="caption" color="white" textAlign='center' fontSize={14} fontWeight='600'>
                                  {ethers.utils.formatEther(item.totalPrice)}
                                </Typography>
                              </Grid>
                            </>
                        }
                        </Grid>

                        {/* Game and latest price */}
                        <Grid display='flex' justifyContent='space-between' alignItems='flex-start'>
                        {
                            <>
                              {
                                (item.team) && (
                                  <Grid display='flex' alignItems='center'>
                                    <Typography variant="caption" color='white' textAlign='center' fontSize={14} fontWeight='600'>
                                      {item.game}
                                    </Typography>
                                  </Grid>
                                )
                              }
                              <Grid display='flex' justifyContent='flex-end' alignItems='center'>
                              {
                                (item.latestPrice > 0) ? (
                                  <>
                                    <Typography variant="caption" color='white'>
                                      Last
                                    </Typography>
                                    <img
                                        src='../../assets/ether-gold.png'
                                        alt='logo'
                                        width={14}
                                        height={14}
                                        style={{ marginLeft: 2, marginRight: 2 }}
                                    />
                                    <Typography variant="caption" color="white" fontWeight='bold'>
                                      {ethers.utils.formatEther(item.latestPrice)}
                                    </Typography>
                                    </>
                                ) : (
                                  <Typography variant="caption" color='white' fontWeight='bold' letterSpacing={2}>
                                    NEW
                                  </Typography>
                                )
                              }
                              </Grid>
                            </>
                        }
                        </Grid>

                      </CardContent>
                    </CardActionArea>
                    <CardActions sx={{ display: 'flex', justifyContent: 'center'}}>
                      <Button 
                        size="small" 
                        color="primary" 
                        variant="outlined"
                        component="label"
                        onClick={() => handleClickPurchaseItem(item)}
                      >
                        Buy now
                      </Button>
                    </CardActions>
                  </Card>
                ))
              }
          </Grid>
        </>
      )
      : (
        <Grid display='flex' justifyContent='center'>
          <Typography color='white' variant='h5'>
            Oops.. no listed assets
          </Typography>
        </Grid>
      )
    }
    </Container>
  )
}
