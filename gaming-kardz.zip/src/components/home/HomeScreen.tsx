import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Container, Typography, Grid, Button, Box, useMediaQuery, useTheme, Link, IconButton } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import SellIcon from '@mui/icons-material/Sell';
import PaidIcon from '@mui/icons-material/Paid';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import EmailIcon from '@mui/icons-material/Email';

export const HomeScreen = () => {

  const navigate = useNavigate();
  const [height, setHeight] = useState(window.innerHeight);
  const theme = useTheme();
  const isSmOrLess = useMediaQuery(theme.breakpoints.down('md'));
  const isMdOrLess = useMediaQuery(theme.breakpoints.down('lg'));

  useEffect(() => {
    const handleResize = () => {
      setHeight(window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <>
      <Container maxWidth='xl' style={{ background: 'linear-gradient(to right bottom, #0c1410, #192112)' }}>
        {/* Explore Section */}
        <Grid 
          container 
          display='flex' 
          justifyContent='center'
          alignItems='center'
          columnSpacing={8} 
          sx={{ height: height - 50 }}
        >
          <Grid item xs={12} md={5} sx={{ marginLeft: { xs: 1, md: 0 }, marginRight: { xs: 1, md: 0 } }}>
            <Typography 
              color='white' 
              align={ (isSmOrLess ? 'center' : 'inherit' )}
              style={{ letterSpacing: 4 }}
              variant={(isSmOrLess ? 'h4' : 'h2')} 
              sx={{ fontWeight: '600', mt: { xs: 4, md: 0 } }} 
            >
              Buy NFTs of your favorites players.
            </Typography>
            <Typography 
              color='white' 
              align={ (isSmOrLess ? 'center' : 'inherit' )}
              variant={(isSmOrLess ? 'body1' : 'h6')} 
              sx={{ marginTop: 3 }}
            >
              Find all players in the world and buy the player that you want.
            </Typography>
            <Typography 
              color='white' 
              align={ (isSmOrLess ? 'center' : 'inherit' )}
              variant={(isSmOrLess ? 'body1' : 'h6')} 
              sx={{ marginTop: 3 }} 
            >
              New NFTs appear every month, check the marketplace to know what they are.
            </Typography>
            <Grid item display='flex' justifyContent={ (isSmOrLess ? 'center' : 'none') }>
              <Button 
                variant="outlined"
                sx={{ 
                  fontWeight: 'bold',
                  marginTop: { xs: 5, md: 6 }, 
                  pt: { xs: 1, md: 2 },
                  pb: { xs: 1, md: 2 },
                  pl: { xs: 3, md: 6 },
                  pr: { xs: 3, md: 6 },
                }} 
                onClick={() => navigate('/market')}
              >
                Explore
              </Button>
            </Grid>
          </Grid>
          <Grid item xs={12} md={4} display='flex' justifyContent='center'>
            <Box
              component="img"
              sx={{
                maxHeight: { xs: 250, md: 500 },
                maxWidth: { xs: 350, md: 500 },
              }}
              alt="The house from the offer."
              src="../../assets/vitality-home.png"
            />
          </Grid>
        </Grid>


        {/* Sell Section */}
        <Grid container sx={{ marginTop: 6, marginBottom: 12 }}>
          <Grid 
            container 
            display='flex' 
            justifyContent='center'
            columnSpacing={8} 
          >
            <Grid 
              item 
              xs={12} 
              md={4} 
              display='flex' 
              justifyContent='center' 
              alignItems='center'
              order={{ xs: 2, md: 1 }}
            >
              <Box
                component="img"
                sx={{
                  maxHeight: { xs: 250, md: 350 },
                  maxWidth: { xs: 350, md: 350 },
                  marginTop: { xs: 5, md: 0 }
                }}
                alt="Sell"
                src="../../assets/sell-home.png"
              />
            </Grid>
            <Grid 
              item 
              xs={12} 
              md={5} 
              order={{ xs: 1, md: 2 }}
              sx={{ marginLeft: { xs: 1, md: 0 }, marginRight: { xs: 1, md: 0 } }} 
            >
              <Typography 
                color='white' 
                align={ (isSmOrLess ? 'center' : 'inherit' )}
                style={{ letterSpacing: 4 }}
                variant={(isSmOrLess ? 'h4' : 'h3')} 
                sx={{ fontWeight: '500', mt: { xs: 4, md: 0 } }} 
              >
                Sell your NFTs and make huge profits.
              </Typography>
              <Typography 
                color='white' 
                align={ (isSmOrLess ? 'center' : 'inherit' )}
                variant={(isSmOrLess ? 'body1' : 'h6')} 
                sx={{ marginTop: 3 }}
              >
                Speculate and sell your NFT when your player is in a big moment.
              </Typography>
              <Typography 
                color='white' 
                align={ (isSmOrLess ? 'center' : 'inherit' )}
                variant={(isSmOrLess ? 'body1' : 'h6')} 
                sx={{ marginTop: 3 }} 
              >
                Specity any price that you want.
              </Typography>
            </Grid>
          </Grid>
        </Grid>



        {/* Royalties Section */}
        <Grid container >
          <Grid 
            item 
            xs={12}
            sx={{ paddingBottom: 20, marginTop: 10, marginLeft: { xs: 1, md: 0 }, marginRight: { xs: 1, md: 0 } }}
          >
            <Typography 
                color='white' 
                align={ (isSmOrLess ? 'center' : 'inherit' )}
                style={{ letterSpacing: 4 }}
                variant={(isSmOrLess ? 'h4' : 'h3')} 
                textAlign='center'
              >
                Earn royalites from NFT sales.
              </Typography>
              <Typography 
                color='white' 
                align={ (isSmOrLess ? 'center' : 'inherit' )}
                variant={(isSmOrLess ? 'body1' : 'h6')} 
                sx={{ marginTop: 2 }}
                textAlign='center'
              >
                Be the first to buy a NFT minted to earn royalties for life.
              </Typography>
              <Grid 
                container 
                display='flex'
                justifyContent='space-evenly'
                sx={{ marginTop: 10 }}
              >
                <Grid item xs={12} md={3} sx={{ paddingTop: { xs: 0, md: 4 }, paddingBottom: 4 }} display='flex' justifyContent='center'>
                  <Box 
                    width={280} 
                    border={0.1}
                    borderColor='#d0f177'
                    sx={{ borderRadius: '24px', paddingTop: 2, paddingBottom: 2 }}
                    style={{ background: 'linear-gradient(to right bottom, #192112, #5e7b37)' }}
                  >
                    <Grid item display='flex' justifyContent='center' alignItems='center'>
                      <ShoppingCartIcon sx={{ color: '#d0f177', fontSize: 96 }}  />
                    </Grid>
                    <Typography 
                      color='white' 
                      fontWeight='bold'
                      align={ (isSmOrLess ? 'center' : 'inherit' )}
                      variant={(isSmOrLess ? 'body1' : 'h6')} 
                      textAlign='center'
                      sx={{ marginTop: 2 }}
                    >
                      BUY NEWONE NFT
                    </Typography>
                  </Box>
                </Grid>
                <Grid 
                  item 
                  xs={12} 
                  md={3} 
                  display='flex' 
                  justifyContent='center'
                  sx={{ paddingTop: 4, paddingBottom: 4 }} 
                >
                  <Box 
                    width={280} 
                    border={0.1}
                    borderColor='#d0f177'
                    sx={{ borderRadius: '24px', paddingTop: 2, paddingBottom: 2 }}
                    style={{ background: 'linear-gradient(to right bottom, #192112, #5e7b37)' }}
                  >
                    <Grid item display='flex' justifyContent='center'>
                      <SellIcon sx={{ color: '#d0f177', fontSize: 96 }} />
                    </Grid>
                    <Grid item>
                      <Typography 
                        color='white' 
                        fontWeight='bold'
                        align={ (isSmOrLess ? 'center' : 'inherit' )}
                        variant={(isSmOrLess ? 'body1' : 'h6')} 
                        textAlign='center'
                        sx={{ marginTop: 2 }}
                      >
                        SELL NFT
                      </Typography>
                    </Grid>
                  </Box>
                </Grid>
                <Grid 
                  item 
                  xs={12} 
                  md={3} 
                  display='flex' 
                  justifyContent='center'
                  sx={{ paddingTop: 4, paddingBottom: 4 }} 
                >
                  <Box 
                    width={280} 
                    border={0.1}
                    borderColor='#d0f177'
                    sx={{ borderRadius: '24px', paddingTop: 2, paddingBottom: 2 }}
                    style={{ background: 'linear-gradient(to right bottom, #192112, #5e7b37)' }}
                  >
                    <Grid item display='flex' justifyContent='center'>
                      <PaidIcon sx={{ color: '#d0f177', fontSize: 96 }} />
                    </Grid>
                    <Typography 
                      color='white' 
                      fontWeight='bold'
                      align={ (isSmOrLess ? 'center' : 'inherit' )}
                      variant={(isSmOrLess ? 'body1' : 'h6')} 
                      textAlign='center'
                      sx={{ marginTop: 2 }}
                    >
                      EARN ROYALTIES
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
          </Grid>
        </Grid>
      </Container>


      {/* Footer Section */}
      <Container maxWidth='xl' sx={{ background: 'black', paddingTop: 10 }}>

        <Grid 
          container 
          sx={{ marginBottom: { xs: 4, md: 0 } }}
        >
          {/* Gaming Kardz */}
          <Grid 
            item 
            xs={12} 
            md={3} 
          >
            <Grid item display='flex' alignItems='center' justifyContent='center'>
              <img
                  src='../../assets/logo.png'
                  alt='logo'
                  width={32}
                  height={32}
                  style={{ marginRight: 7 }}
              />
              <Typography 
                color='#d0f177' 
                variant={isSmOrLess ? 'h6' : (isMdOrLess ? 'h6' : 'h5')} 
                sx={{ fontWeight: 'bold' }} 
                style={{ letterSpacing: 2 }}
              >
                GAMING KARDZ
              </Typography>
            </Grid>
            <Grid 
              item 
              display='flex' 
              justifyContent='center' 
              sx={{ mt: { xs: 0, md: 2 } }}
            >
              <IconButton sx={{ mt: 2, mb: 2, ml: 2, mr: 2 }}>
                <Link
                  href='https://www.linkedin.com/in/christian-g-perez/'
                  variant='body2'
                >
                  <LinkedInIcon sx={{ color: 'darkgray', fontSize: 24 }} />
                </Link>
              </IconButton>
              <IconButton sx={{ mt: 2, mb: 2, ml: 2, mr: 2 }}>
                <Link
                  href='https://www.instagram.com/gamingkardz/'
                  variant='body2'
                >
                  <InstagramIcon sx={{ color: 'darkgray', fontSize: 24 }} />
                </Link>
              </IconButton>
              <IconButton sx={{ mt: 2, mb: 2, ml: 2, mr: 2 }}>
                <Link
                  href='https://www.twitter.com/gamingkardz/'
                  variant='body2'
                >
                  <TwitterIcon sx={{ color: 'darkgray', fontSize: 24 }} />
                </Link>
              </IconButton>
            </Grid>
          </Grid>

          {/* Information */}
          <Grid 
            item 
            xs={12}
            md={3}
            sx={{ marginLeft: 'auto', marginBottom: { xs: 5, md: 0 } }}
          >
            <Typography 
              color='white' 
              textAlign={(isSmOrLess ? 'center' : 'unset')}
              sx={{ marginBottom: { xs: 1, md: 3 } }} 
            >
              Information
            </Typography>
            <Link 
              href="#" 
              underline="hover" 
              onClick={() => console.log('development')} 
              color="darkgray" 
            >
              <Typography textAlign={(isSmOrLess ? 'center' : 'unset')}>
                {'Development'}
              </Typography>
            </Link>
          </Grid>

          {/* Contact */}
          <Grid 
            item 
            xs={12}
            md={3}
            sx={{ marginRight: 'auto', marginBottom: { xs: 5, md: 0 } }}
          >
            <Typography color='white' sx={{ marginBottom: { xs: 1, md: 3 } }} textAlign={(isSmOrLess ? 'center' : 'unset')}>
              Contact
            </Typography>
            <Link 
              href="#" 
              underline="hover" 
              onClick={() => console.log('mail to christiangperez')} 
              color="darkgray" 
            >
              <Typography textAlign={(isSmOrLess ? 'center' : 'unset')}>
                {'christiangperez@gmail.com'}
              </Typography>
            </Link>
          </Grid>
        </Grid> 

        {/* Rights Reserved */}
        <Grid item sx={{ background: 'black', paddingBottom: 5, paddingTop: { xs: 1, md: 5 } }} xs={12}>
          <hr />
          <Typography color='white' textAlign='center' sx={{ paddingTop: 2 }}>
            © Gaming Kardz 2022. All Rights Reserved.
          </Typography>
        </Grid>
      </Container>
    </>
  )
}
